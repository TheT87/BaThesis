
 TUD-Script &ndash; Corporate Design of Technische Universität Dresden
----------------------------------------------------------------------------

 Copyright (C) Falk Hanisch <hanisch.latex@outlook.com>, 2012-2021

----------------------------------------------------------------------------

 This work may be distributed and/or modified under the conditions of the
 LaTeX Project Public License, either version 1.3c of this license or
 any later version. The latest version of this license is in<br>
 &emsp;http://www.latex-project.org/lppl.txt<br>
 and version 1.3c or later is part of all distributions of
 LaTeX version 2008-05-04 or later.
 
 This work has the LPPL maintenance status "maintained".
 
 The current maintainer and author of this work is Falk Hanisch.

----------------------------------------------------------------------------

 However, only members of the  Technische Universität Dresden are permitted 
 to publish documents in the corporate design, in particular with the use 
 of an official logo.

----------------------------------------------------------------------------
